import os
from datetime import datetime
from flask import Blueprint, render_template, request, redirect, url_for, flash, send_from_directory, current_app, jsonify
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from . import db
from .models import User, Video, Like, Comment, Follow, Friendship, Message, Notification
from .forms import LoginForm, RegisterForm, CommentForm, MessageForm

bp = Blueprint("main", __name__)

@bp.app_template_filter("dt")
def _fmt_dt(value):
    return value.strftime("%Y-%m-%d %H:%M")

@bp.route("/")
def index():
    q = request.args.get("q", "").strip()
    if q:
        videos = Video.query.filter(Video.title.ilike(f"%{q}%")).order_by(Video.created_at.desc()).all()
    else:
        videos = Video.query.order_by(Video.created_at.desc()).all()
    return render_template("index.html", videos=videos, q=q)

@bp.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    form = RegisterForm()
    if form.validate_on_submit():
        if User.query.filter_by(username=form.username.data).first():
            flash("Username already exists", "warning")
            return redirect(url_for("main.register"))
        u = User(username=form.username.data, password=generate_password_hash(form.password.data))
        db.session.add(u); db.session.commit()
        flash("Account created. Please login.", "success")
        return redirect(url_for("main.login"))
    return render_template("register.html", form=form)

@bp.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("main.index"))
    form = LoginForm()
    if form.validate_on_submit():
        u = User.query.filter_by(username=form.username.data).first()
        if u and check_password_hash(u.password, form.password.data):
            login_user(u)
            return redirect(url_for("main.index"))
        flash("Invalid credentials", "danger")
    return render_template("login.html", form=form)

@bp.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("main.index"))

# ---- Videos ----

@bp.route("/upload", methods=["GET", "POST"])
@login_required
def upload():
    if request.method == "POST":
        f = request.files.get("file")
        title = request.form.get("title") or f.filename
        desc = request.form.get("description", "")
        if not f:
            flash("No file", "warning")
            return redirect(url_for("main.upload"))
        path = os.path.join(current_app.config["UPLOAD_FOLDER"], f.filename)
        os.makedirs(current_app.config["UPLOAD_FOLDER"], exist_ok=True)
        f.save(path)
        v = Video(user_id=current_user.id, title=title, filename=f.filename, description=desc, is_vertical=True)
        db.session.add(v); db.session.commit()
        flash("Uploaded!", "success")
        return redirect(url_for("main.watch", video_id=v.id))
    return render_template("upload.html")

@bp.route("/watch/<int:video_id>", methods=["GET", "POST"])
def watch(video_id):
    v = Video.query.get_or_404(video_id)
    form = CommentForm()
    if form.validate_on_submit() and current_user.is_authenticated:
        c = Comment(user_id=current_user.id, video_id=v.id, text=form.text.data)
        db.session.add(c); db.session.commit()
        # notify owner
        if current_user.id != v.user_id:
            db.session.add(Notification(user_id=v.user_id, text=f"{current_user.username} commented on your video"))
            db.session.commit()
        return redirect(url_for("main.watch", video_id=video_id))
    like_count = Like.query.filter_by(video_id=v.id).count()
    is_liked = False
    if current_user.is_authenticated:
        is_liked = Like.query.filter_by(video_id=v.id, user_id=current_user.id).first() is not None
        is_following = Follow.query.filter_by(user_id=v.user_id, follower_id=current_user.id).first() is not None
        is_friend = Friendship.query.filter(
            ((Friendship.requester_id==current_user.id) & (Friendship.addressee_id==v.user_id) & (Friendship.status=="accepted")) |
            ((Friendship.addressee_id==current_user.id) & (Friendship.requester_id==v.user_id) & (Friendship.status=="accepted"))
        ).first() is not None
    else:
        is_following = False
        is_friend = False
    more_videos = Video.query.filter(Video.id != v.id).order_by(Video.created_at.desc()).limit(10).all()
    return render_template("watch.html", v=v, form=form, like_count=like_count,
                           is_liked=is_liked, is_following=is_following, is_friend=is_friend, more_videos=more_videos)

@bp.route("/like/<int:video_id>", methods=["POST"])
@login_required
def like(video_id):
    v = Video.query.get_or_404(video_id)
    existing = Like.query.filter_by(video_id=v.id, user_id=current_user.id).first()
    if existing:
        db.session.delete(existing)
    else:
        db.session.add(Like(video_id=v.id, user_id=current_user.id))
        if current_user.id != v.user_id:
            db.session.add(Notification(user_id=v.user_id, text=f"{current_user.username} liked your video"))
    db.session.commit()
    return jsonify({"ok": True})

# ---- Follow ----
@bp.route("/follow/<int:user_id>", methods=["POST"])
@login_required
def follow(user_id):
    if user_id == current_user.id:
        return jsonify({"ok": False, "msg": "Cannot follow yourself"}), 400
    existing = Follow.query.filter_by(user_id=user_id, follower_id=current_user.id).first()
    if existing:
        db.session.delete(existing)
        msg = "unfollowed"
    else:
        db.session.add(Follow(user_id=user_id, follower_id=current_user.id))
        db.session.add(Notification(user_id=user_id, text=f"{current_user.username} started following you"))
        msg = "followed"
    db.session.commit()
    return jsonify({"ok": True, "status": msg})

# ---- Friends ----
@bp.route("/friend/<int:user_id>", methods=["POST"])
@login_required
def friend(user_id):
    if user_id == current_user.id:
        return jsonify({"ok": False, "msg": "Cannot add yourself"}), 400
    # check if already pending/accepted
    rel = Friendship.query.filter(
        ((Friendship.requester_id==current_user.id) & (Friendship.addressee_id==user_id)) |
        ((Friendship.requester_id==user_id) & (Friendship.addressee_id==current_user.id))
    ).first()
    if rel:
        if rel.status == "pending" and rel.addressee_id == current_user.id:
            rel.status = "accepted"
            db.session.add(Notification(user_id=user_id, text=f"{current_user.username} accepted your friend request"))
            db.session.commit()
            return jsonify({"ok": True, "status": "accepted"})
        # toggle remove
        db.session.delete(rel)
        db.session.commit()
        return jsonify({"ok": True, "status": "removed"})
    # create new request
    fr = Friendship(requester_id=current_user.id, addressee_id=user_id, status="pending")
    db.session.add(fr)
    db.session.add(Notification(user_id=user_id, text=f"{current_user.username} sent you a friend request"))
    db.session.commit()
    return jsonify({"ok": True, "status": "requested"})

@bp.route("/friends")
@login_required
def friends_page():
    pending = Friendship.query.filter_by(addressee_id=current_user.id, status="pending").all()
    accepted = Friendship.query.filter(
        ((Friendship.requester_id==current_user.id) & (Friendship.status=="accepted")) |
        ((Friendship.addressee_id==current_user.id) & (Friendship.status=="accepted"))
    ).all()
    return render_template("friends.html", pending=pending, accepted=accepted)

# ---- Messages ----
@bp.route("/messages", methods=["GET", "POST"])
@login_required
def messages():
    receiver_id = request.args.get("to", type=int)
    users = User.query.order_by(User.username).all()
    msgs = []
    form = MessageForm()
    if receiver_id:
        if form.validate_on_submit():
            m = Message(sender_id=current_user.id, receiver_id=receiver_id, text=form.text.data)
            db.session.add(m); db.session.commit()
            return redirect(url_for("main.messages", to=receiver_id))
        msgs = Message.query.filter(
            ((Message.sender_id==current_user.id) & (Message.receiver_id==receiver_id)) |
            ((Message.sender_id==receiver_id) & (Message.receiver_id==current_user.id))
        ).order_by(Message.created_at).all()
    return render_template("messages.html", users=users, msgs=msgs, receiver_id=receiver_id, form=form)

# ---- Notifications ----
@bp.route("/notifications")
@login_required
def notifications():
    items = Notification.query.filter_by(user_id=current_user.id).order_by(Notification.created_at.desc()).all()
    return render_template("notifications.html", items=items)

# ---- Reels ----
@bp.route("/reels")
def reels():
    videos = Video.query.filter_by(is_vertical=True).order_by(Video.created_at.desc()).all()
    return render_template("reels.html", videos=videos)

# serve uploads
@bp.route("/uploads/<path:filename>")
def uploaded_file(filename):
    from flask import current_app, send_from_directory
    return send_from_directory(current_app.config["UPLOAD_FOLDER"], filename)