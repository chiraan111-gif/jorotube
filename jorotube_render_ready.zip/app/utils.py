from flask import url_for

def share_links(video_id):
    url = url_for('main.watch', video_id=video_id, _external=True)
    return {
        "whatsapp": f"https://wa.me/?text=Watch this: {url}",
        "facebook": f"https://www.facebook.com/sharer/sharer.php?u={url}",
        "copy": url
    }