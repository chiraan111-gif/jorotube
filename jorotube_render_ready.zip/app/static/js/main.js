document.addEventListener("click", async (e) => {
  const like = e.target.closest("#likeBtn");
  const follow = e.target.closest("#followBtn");
  const friend = e.target.closest("#friendBtn");
  if (like) {
    const id = like.dataset.id;
    const res = await fetch(`/like/${id}`, {method:"POST"});
    if (res.ok) location.reload();
  }
  if (follow) {
    const id = follow.dataset.id;
    const res = await fetch(`/follow/${id}`, {method:"POST"});
    if (res.ok) location.reload();
  }
  if (friend) {
    const id = friend.dataset.id;
    const res = await fetch(`/friend/${id}`, {method:"POST"});
    if (res.ok) location.reload();
  }
});