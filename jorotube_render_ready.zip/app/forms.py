from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, BooleanField, FileField
from wtforms.validators import DataRequired, Length

class LoginForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired()])
    password = PasswordField("Password", validators=[DataRequired()])

class RegisterForm(FlaskForm):
    username = StringField("Username", validators=[DataRequired(), Length(min=3, max=80)])
    password = PasswordField("Password", validators=[DataRequired(), Length(min=4)])

class CommentForm(FlaskForm):
    text = StringField("Comment", validators=[DataRequired(), Length(min=1, max=500)])

class MessageForm(FlaskForm):
    text = StringField("Message", validators=[DataRequired(), Length(min=1, max=1000)])